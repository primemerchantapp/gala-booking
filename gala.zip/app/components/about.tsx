export default function About() {
  return (
    <section className="py-16">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-8 text-center">About Gala</h2>
        <div className="max-w-2xl mx-auto text-center">
          <p className="text-gray-600 mb-4">
            Gala is your ultimate companion for finding the perfect stay in the Philippines. We offer a wide selection
            of hotels and resorts across the beautiful islands of the country.
          </p>
          <p className="text-gray-600">
            Whether you're looking for a luxurious beachfront resort in Boracay, a cozy hotel in the heart of Manila, or
            a serene retreat in Palawan, Gala has got you covered. Start your Philippine adventure with us today!
          </p>
        </div>
      </div>
    </section>
  )
}

